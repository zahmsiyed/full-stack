import React from "react";

// Description: Provides buttons to change the counter value
function CounterControls({ increment, decrement }) {
  return (
    <div className="counter-controls">
      <button type="button" onClick={increment}>
        Increase
      </button>
      <button type="button" onClick={decrement}>
        Decrease
      </button>
    </div>
  );
}

export default CounterControls;
