import React from "react";

// Description: Shows the current value of the counter
function CounterDisplay({ counter }) {
  return <div className="counter-display">Counter: {counter}</div>;
}

export default CounterDisplay;
