import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { ThemeContext } from "../context/themecontext";
import "./Navbar.css";

function Navbar() {
  const { theme, toggleTheme } = useContext(ThemeContext);
  const themeClass = theme === "dark" ? "dark" : "light";
  const nextTheme = theme === "light" ? "dark" : "light";

  return (
    <nav className={`navbar ${themeClass} navbar-${themeClass}`}>
      <Link className="nav-link" to="/home">
        Home
      </Link>
      <Link className="nav-link" to="/counter">
        Counter
      </Link>
      <button
        type="button"
        aria-label={`Switch to ${nextTheme} mode`}
        onClick={toggleTheme}
      >
        Toggle Theme
      </button>
    </nav>
  );
}

export default Navbar;
